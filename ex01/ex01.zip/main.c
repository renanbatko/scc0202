#include <stdio.h>
#include "complexo.h"

int main(void){
	Complexo *p;
	p = criar(2, 3);
	liberar(p);
	
	return 0;
}
